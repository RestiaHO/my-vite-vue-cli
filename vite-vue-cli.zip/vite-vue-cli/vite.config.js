import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'
import ViteComponents, {
  NaiveUiResolver
} from "vite-plugin-components"

// https://vitejs.dev/config/
export default defineConfig({
  root: './src/views/',
  base: '/',
  plugins: [
    vue(),
    ViteComponents({
    customComponentResolvers: [
      NaiveUiResolver(),//官方插件提供
    ]
  })],

  server: {
    host: "0.0.0.0",
    // 设为 true 时若端口已被占用则会直接退出，而不是尝试下一个可用端口。
    strictPort: false,
    port: 8080,
    proxy: {
      '/api': {
        target: 'http://jsonplaceholder.typicode.com',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '')
      },
    }
    // force: true
  },
  resolve: {
    alias: {
      // '~': path.resolve(__dirname, './'), // 根路径
      '@': path.resolve(__dirname, 'src'),
      // components: path.resolve(__dirname, 'src/components'),
      // assets: path.resolve(__dirname, 'src/assets'),
      // views: path.resolve(__dirname, 'src/views'),
      // utils: path.resolve(__dirname, 'src/utils'),
      // apis: path.resolve(__dirname, 'src/apis'),
    },
  },
  build:{
    target: 'modules',
    // 计算大小
    brotliSize: false,
    // 清空文件
    emptyOutDir: true,
    assetsDir: 'static/img/',
    outDir: '../../dist',
    // 项目部署的基础路径
    base: '/',
    mode: 'development',
    rollupOptions: {
      input: {
        main: path.resolve(__dirname, 'src/views/index.html'),
        admin: path.resolve(__dirname, 'src/views/admin/index.html'),
        example: path.resolve(__dirname, 'src/views/example/index.html')
      },
      output: {
        chunkFileNames: 'static/js/[name]-[hash].js',
        entryFileNames: 'static/js/[name]-[hash].js',
        assetFileNames: 'static/[ext]/[name]-[hash].[ext]',
      },
    },
  }
})
