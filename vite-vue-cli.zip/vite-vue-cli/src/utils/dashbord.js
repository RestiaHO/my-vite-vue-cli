import API from './api'

export function query(params) {
    console.log('111223123')
    return API.get('', params)
}
