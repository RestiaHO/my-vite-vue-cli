import axios from 'axios'
import to from 'await-to-js'

function API() {
    let that = this

    this.prefix = ( import.meta.env.MODE === 'development') ? '' : '/demo/api'
    this.url = function (url) {
        return this.prefix + url
    }

    this.get = function (url, params) {
        console.log('windwos', window)
        let headers = {
            'Token': sessionStorage.getItem('currentToken')
        }
        return to(new Promise((resolve, reject) => {
            axios.get(that.url(url), {params, headers}).then(res => {
                resolve(res.data)
                if (res.data.code === '401' || res.data.code === 401) {
                    window.vm.onLogout(true)
                    window.vm.$refs.msg.showMessage('登录已失效', 'warning')
                }
            }).catch(err => {
                switch (err.response.status) {
                    case 403: {
                        window.vm.onLogout(true)
                        return
                    }
                }
                reject(err.response)
            })
        }))
    }

    this.post = function (url, params) {
        params = params || {}
        let config = {
            headers: {
                'Content-Type': 'application/json',
                'Token': sessionStorage.getItem('currentToken')
            }
        }
        return to(new Promise((resolve, reject) => {
            axios.post(that.url(url), params, config).then(res => {
                resolve(res.data)
                if (res.data.code === '401' || res.data.code === 401) {
                    window.vm.onLogout(true)
                    window.vm.$refs.msg.showMessage('登录已失效', 'warning')
                }
            }).catch(err => {
                switch (err.response.status) {
                    case 403: {
                        window.vm.onLogout(true)
                        return
                    }
                }
                reject(err.response)
            })
        }))
    }

    this.put = function (url, params) {
        let config = {
            headers: {
                'Content-Type': 'application/json',
                'Token': sessionStorage.getItem('currentToken')
            }
        }
        return to(new Promise((resolve, reject) => {
            axios.put(that.url(url), params, config).then(res => {
                resolve(res.data)
                if (res.data.code === '401' || res.data.code === 401) {
                    window.vm.onLogout(true)
                    window.vm.$refs.msg.showMessage('登录已失效', 'warning')
                }
            }).catch(err => {
                switch (err.response.status) {
                    case 403: {
                        window.vm.onLogout(true)
                        return
                    }
                }
                reject(err.response)
            })
        }))
    }

    this.delete = function (url, params) {
        let headers = {
            'Token': sessionStorage.getItem('currentToken')
        }
        return to(new Promise((resolve, reject) => {
            axios.delete(that.url(url), {params, headers}).then(res => {
                resolve(res.data)
                if (res.data.code === '401' || res.data.code === 401) {
                    window.vm.onLogout(true)
                    window.vm.$refs.msg.showMessage('登录已失效', 'warning')
                }
            }).catch(err => {
                switch (err.response.status) {
                    case 403: {
                        window.vm.onLogout(true)
                        return
                    }
                }
                reject(err.response)
            })
        }))
    }

    this.postFile = function (url, params) {
        params = params || {}
        let config = {
            headers: {
                'Content-Type': 'application/json',
                'Token': sessionStorage.getItem('currentToken')
            },
            responseType: 'blob'
        }
        return to(new Promise((resolve, reject) => {
            axios.post(that.url(url), params, config).then(res => {
                resolve(res.data)
                if (res.data.code === '401' || res.data.code === 401) {
                    window.vm.onLogout(true)
                }
            }).catch(err => {
                switch (err.response.status) {
                    case 403: {
                        window.vm.onLogout(true)
                        return
                    }
                }
                reject(err.response)
            })
        }))
    }

    // 流文件获取，返回整个res
    this.postFileNew = function (url, params) {
        params = params || {}
        let config = {
            headers: {
                'Content-Type': 'application/json',
                'Token': sessionStorage.getItem('currentToken')
            },
            responseType: 'blob'
        }
        return to(new Promise((resolve, reject) => {
            axios.post(that.url(url), params, config).then(res => {
                resolve(res)
            }).catch(err => {
                switch (err.response.status) {
                    case 403: {
                        window.vm.onLogout(true)
                        return
                    }
                }
                reject(err.response)
            })
        }))
    }
}

export default new API()
