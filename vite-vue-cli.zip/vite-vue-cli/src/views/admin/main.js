import { createApp } from 'vue'
import App from './App.vue'
import router from './router/index.js'
import store from '@/store/index.js'
import lodash from 'lodash'

const app = createApp(App)

console.log('11111111', import.meta.env.MODE)
app.config.globalProperties._ = lodash
app.use(router)
app.use(store)
app.mount('#app')
