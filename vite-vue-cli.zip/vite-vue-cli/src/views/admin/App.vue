<template>
  <router-view></router-view>
</template>

<script>
  import {useRouter} from "vue-router";
  import { defineComponent } from 'vue'
  export default defineComponent({
    setup () {
      return {
        router: useRouter()
      }
    }
  })
</script>
<style scoped>
  .n-divider {
    margin: unset;
  }
</style>
<style>

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  /*-webkit-font-smoothing: antialiased;*/
  /*-moz-osx-font-smoothing: grayscale;*/
  /*text-align: center;*/
  /*color: #2c3e50;*/
}
</style>
