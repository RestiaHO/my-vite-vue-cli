// 引入vue-router对象
import { createRouter, createWebHashHistory } from "vue-router";
import store from '@/store/index.js'
/**
 * 定义路由数组
 */

/**
 * Note: 子菜单仅当路由的children.length >= 1时才出现
 *
 * hidden: true                   设置为true时路由将显示在sidebar中(默认false)
 * alwaysShow: true               如果设置为true则总是显示在菜单根目录
 *                                如果不设置alwaysShow, 当路由有超过一个子路由时,
 *                                将会变为嵌套模式, 否则不会显示根菜单
 * redirect: noRedirect           如果设置noRedirect时，breadcrumb中点击将不会跳转
 * name:'router-name'             name用于<keep-alive> (必须设置!!!)
 * meta : {
    roles: ['admin','editor']    页面可访问角色设置
    title: 'title'               sidebar和breadcrumb显示的标题
    icon: 'svg-name'/'el-icon-x' sidebar中显示的图标
    breadcrumb: false            设置为false，将不会出现在面包屑中
    activeMenu: '/example/list'  如果设置一个path, sidebar将会在高亮匹配项
  }
 */

const routes = [
    // {
    //     path: '/',
    //     name: 'Layout',
    //     component: () => import('../components/ad2.vue'),
    //     meta: {
    //       title: '布局',
    //       icon:''
    //     },
    //     children: []
    // },
];

/**
 * 创建路由
 */
const router = createRouter({
    // hash模式：createWebHashHistory，
    // history模式：createWebHistory
    history: createWebHashHistory("/admin/index.html"),
    routes
});

/**
 * 路由守卫
 */
const user = sessionStorage.getItem('current')
// router.beforeEach((to, from, next) => {
//     if (!user) next({name: 'Login'})
//     console.log(user)
//     if (user && !to.name) next({name: 'Home'})
//     // else next()
//     // beforeEach.checkAuth(guard, router);
// });
// router.afterEach((to, from) => {
//     const toDepth = to.path.split('/').length
//     const fromDepth = from.path.split('/').length
//     to.meta.transitionName = toDepth < fromDepth ? 'component-fade' : 'component-fade'
// })
router.beforeEach((to, from, next) => {
    // if (!user && to.name !== 'Login') next({ name: 'Login' })
    // else next()
    next()
})

/**
 * 路由错误回调
 */
router.onError((handler) => {
    console.log("error:", handler);
});

/**
 * 输出对象
 */
export default router
