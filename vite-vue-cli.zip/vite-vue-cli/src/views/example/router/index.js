// 引入vue-router对象
import { createRouter, createWebHashHistory } from "vue-router";
import store from '@/store/index.js'
/**
 * 定义路由数组
 */
const routes = [
    // {
    //     path: '/',
    //     name: 'Layout',
    //     component: () => import('../components/ad1.vue'),
    //     meta: {
    //       title: '布局',
    //       icon:''
    //     },
    //     children: []
    // }
];

/**
 * 创建路由
 */
const router = createRouter({
    // hash模式：createWebHashHistory，
    // history模式：createWebHistory
    history: createWebHashHistory("/example/index.html"),
    routes
});

/**
 * 路由守卫
 */
const user = sessionStorage.getItem('current')
// router.beforeEach((to, from, next) => {
//     if (!user) next({name: 'Login'})
//     console.log(user)
//     if (user && !to.name) next({name: 'Home'})
//     // else next()
//     // beforeEach.checkAuth(guard, router);
// });
// router.afterEach((to, from) => {
//     const toDepth = to.path.split('/').length
//     const fromDepth = from.path.split('/').length
//     to.meta.transitionName = toDepth < fromDepth ? 'component-fade' : 'component-fade'
// })
router.beforeEach((to, from, next) => {
    // if (!user && to.name !== 'Login') next({ name: 'Login' })
    // else next()
    next()
})

/**
 * 路由错误回调
 */
router.onError((handler) => {
    console.log("error:", handler);
});

/**
 * 输出对象
 */
export default router
