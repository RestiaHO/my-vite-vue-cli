// 移动html脚本
const fs = require('fs')
// 查看src下的所有目录
const dirNames = fs.readdirSync('./dist/src')
// copy
for(let i = 0;i < dirNames.length;i++){
    fs.copyFileSync(`./dist/src/${dirNames[i]}/index.html`, `./dist/${dirNames[i]}.html`)
}
fs.rmdirSync('./dist/src',{recursive:true})
